package ui;

import java.util.Arrays;
import java.util.Scanner;

import Exception.NmExcep;
import data.DataClass;
import service.ServClass;
import service.ServInter;

public class UiClass {
private static String transferAmt;

public static void main(String[] args)throws NmExcep {
	Scanner sc=new Scanner(System.in);
	long phone,account,acc2;
	String name;
	float avBal,bal,depAmt,withAmt,transAmt;
	int c;
	ServInter obj=new ServClass();
	do {
		System.out.println("\n 1.Create Account \n 2.Show Balance \n 3.Deposit \n 4.Withdraw \n 5.Fund Transfer \n 6.Print Transaction \n 7.Exit\n");
		System.out.println("enter your choice:");
		c=sc.nextInt();
		switch(c)
		{
		case 1:try{
			System.out.println("create account:");
		    DataClass dc=new DataClass();
		    System.out.println("enter name:");
		    name=sc.next();
		    obj.nameCheck(name);
			dc.setName(name);
			System.out.println("enter phone number:");
		    phone=sc.nextLong();
			dc.setBal(0L);
			account=phone-9999;
			dc.setAccount(account);
			
			boolean result=obj.createAccount(dc);
			if(result) {
				System.out.println("account created with number:"+account);
			}
		   
		   }catch(NmExcep e)
		    {
				System.out.println("invalid details");
		    }
		    break;
		case 2:System.out.println("balance enquiry");
		       System.out.println("enter account number:");
		       account=sc.nextLong();
		       avBal=obj.checkBal(account);
		       System.out.println("account balance is:"+avBal);
		       break;
		case 3:System.out.println("deposit");
		System.out.println("enter account number:");
	       account=sc.nextLong();
	       System.out.println("enter amount to be deposited:");
	       depAmt=sc.nextFloat();
	       bal=obj.deposit(account,depAmt);
	       System.out.println("balance:"+bal);
	       break;
		case 4:System.out.println("withdraw");
		System.out.println("enter account number:");
	       account=sc.nextLong();
	       System.out.println("enter withdrawing amount:");
	       withAmt=sc.nextFloat();
	       bal=obj.withdraw(withAmt,account);
	       System.out.println("amount withdrwan");
	       System.out.println("balance after withdrwaing:"+bal);
	       break;
		case 5:System.out.println("transfer");
		System.out.println("enter account number:");
	       account=sc.nextLong();
	       System.out.println("enetre receiver acc");
	       acc2=sc.nextLong();
	       System.out.println("enter amount you want to transfer:");
	       transAmt=sc.nextFloat();
	       bal=obj.transfer(account,acc2,transAmt);
	       System.out.println("amount transferred");
	       System.out.println("balance after transfer:"+bal);
		   String transaction=transferAmt+"transferred from"+account+"to"+acc2;
	       new DataClass(transaction);
		break;
		case 6:System.out.println("transaction");
		System.out.println("transaction:");
		System.out.println(Arrays.toString(DataClass.transaction));
		break;
		case 7:System.out.println("thankyou");
		System.exit(0);
		}
	}while(c!=7);
	sc.close();
}
}
