package service;

import java.sql.SQLException;
import java.util.regex.Pattern;

import Exception.NmExcep;
import dao.DaoClass;
import dao.DaoInter;
import data.DataClass;

public class ServClass implements ServInter {
	DaoInter di=new DaoClass();

	@Override
	public float checkBal(long account) {
		float bal=di.checkBal(account);
		return bal;
	}

	@Override
	public float deposit(long account, float depAmt) {
		return di.depoAmt(account,depAmt);
	}

	@Override
	public float withdraw(float withAmt, long account)  {
		return di.withAm(withAmt,account);
	}

	@Override
	public float transfer(long account, long acc2, float transAmt) {
		return di.transfer(account,acc2,transAmt);
	}

	@Override
	public boolean createAccount(DataClass dc) {
		return di.custInfo(dc);
	}

	@Override
	public void nameCheck(String name)throws NmExcep {
		boolean r= Pattern.matches("[a-zA-Z]*",name);
		if(r==false)
		{
			throw new NmExcep(name);
		}
	}

}

