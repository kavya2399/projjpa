package dao;

import data.DataClass;

public interface DaoInter {

	boolean custInfo(DataClass dc);

	float transfer(long account, long acc2, float transAmt);

	float checkBal(Long account);

	float depoAmt(long account, float depAmt);

	float withAm(float withAt, long account);

	

}
