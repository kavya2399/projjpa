package dao;
 
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
 


import data.DataClass;

import java.util.Set;
 
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
 
public class DaoClass implements DaoInter {
	DataClass c=new DataClass();
	EntityManagerFactory emf=null;
	EntityManager em=null;
	
	public boolean custInfo(DataClass dc)

	{
		this.c=dc;
		
		emf=Persistence.createEntityManagerFactory("MiniProject3");
		em=emf.createEntityManager();
		em.getTransaction().begin();
	
		em.persist(c);
		em.getTransaction().commit();
		return true;
	}
	
	
	
	
	
	public float transfer(long account, long acc2, float transAmt){
		float balance=0;
		float rbal=0;
		emf=Persistence.createEntityManagerFactory("MiniProject3");
		em=emf.createEntityManager();
		em.getTransaction().begin();
		DataClass cus=em.find(DataClass.class,account);
		balance=(long) cus.getBal();
		balance=balance-transAmt;
		cus.setBal(balance);
		em.persist(cus);
		em.getTransaction().commit();
 
		emf=Persistence.createEntityManagerFactory("MiniProject3");
		em=emf.createEntityManager();
		em.getTransaction().begin();
		cus=em.find(DataClass.class, acc2);
		rbal=(long) cus.getBal();
		rbal=rbal+transAmt;
		cus.setBal(rbal);
		em.persist(cus);
		em.getTransaction().commit();
		return balance;
	}

	@Override
	public float checkBal(Long account) {
		float balance=0;
		emf=Persistence.createEntityManagerFactory("MiniProject3");
		em=emf.createEntityManager();
		em.getTransaction().begin();
		DataClass cus=em.find(DataClass.class, account);
		balance=(float) cus.getBal();
		em.getTransaction().commit();



return balance;
	}

	@Override
	public float depoAmt(long account, float depAmt) {
		float balance=0;
		emf=Persistence.createEntityManagerFactory("MiniProject3");
		em=emf.createEntityManager();
		em.getTransaction().begin();
		DataClass cus=em.find(DataClass.class, account);
		balance=(long) cus.getBal();
		balance=balance+depAmt;
		cus.setBal(balance);
		em.persist(cus);
		em.getTransaction().commit();
 
 
		return balance;
	}

	@Override
	public float withAm(float withAt, long account) {
		float balance=0;
		 
		emf=Persistence.createEntityManagerFactory("MiniProject3");
		em=emf.createEntityManager();
		em.getTransaction().begin();
		DataClass cus=em.find(DataClass.class, account);
		balance=(long) cus.getBal();
		balance=balance-withAt;
		cus.setBal(balance);
		em.persist(cus);
		em.getTransaction().commit();
 
 
		return balance;
	}
}